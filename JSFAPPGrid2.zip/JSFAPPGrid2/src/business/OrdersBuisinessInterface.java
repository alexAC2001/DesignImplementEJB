package business;

import java.util.List;

import javax.ejb.Local;

import beans.Order;

@Local
public interface OrdersBuisinessInterface {
	public void test();
	public List<Order> getOrder();
	public void setOrders(List<Order> orders);
}
