package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;

@Stateless
@Local(OrdersBuisinessInterface.class)
@Alternative
public class AnotherOrdersBusinessService implements OrdersBuisinessInterface {

	List<Order> orders = new ArrayList<Order>();
	
	@Override
	public void test() {
		System.out.println("======================Hello from the test method from AnotherOrdersBusinessService. Orders Business Service Version #2");			
	}
	
	public AnotherOrdersBusinessService() {
		orders.add(new Order("000a", "This is product 1", (float)15.00, 1));
		orders.add(new Order("000b", "This is product 2", (float)12.00, 14));
		orders.add(new Order("000c", "This is product 3", (float)1.30, 12));
		orders.add(new Order("000d", "This is product 4", (float)12.00, 14));
		orders.add(new Order("000e", "This is product 5", (float)141.00, 34));
		orders.add(new Order("000f", "This is product 6", (float)2.23, 23));
		orders.add(new Order("000g", "This is product 7", (float)2.20, 213));
		orders.add(new Order("000h", "This is product 8", (float)1.24, 56));
		orders.add(new Order("000i", "This is product 9", (float)21.02, 4));
		orders.add(new Order("000j", "This is product 10", (float)4.00, 64));
		orders.add(new Order("000k", "This is product 11", (float)5.02, 3));
		orders.add(new Order("000l", "This is product 12", (float)121.00, 16));
		orders.add(new Order("000m", "This is product 13", (float)0.94, 13));
	}

	@Override
	public List<Order> getOrder() {
		// TODO Auto-generated method stub
		return orders;
	}

	@Override
	public void setOrders(List<Order> orders) {
		this.orders = orders;
		
	}
}
