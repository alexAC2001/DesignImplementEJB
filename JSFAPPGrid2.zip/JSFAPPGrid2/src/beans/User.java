package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.bean.ReferencedBean;

@ManagedBean
@ViewScoped
//@NotNull()
//@Size(min=5, max=15)
public class User {
	// New variables
	private String username;
	private String password;
	
	// This is a default constructor that sets the first/last name
	// to Alexander Carrillo.
	public User() {
		username="Alexander";
		password="Carrillo";
	}

	// These are getters and setters for FirstName and LastName.
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}	
}
