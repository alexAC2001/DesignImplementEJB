package beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
//import javax.faces.view.ViewScoped;

//Annotations
@ManagedBean
//@ViewScoped
public class Orders {

	//New List of type Orders
	// Order is the object and orders is the list.
	List <Order> orders = new ArrayList<Order>(); 
	
	// This default constructor has a predetermined set of data that
	// fills the properties from the Order class.
	public Orders()
	{
		orders.add(new Order("0000", "This is product 1", (float)15.00, 1));
		orders.add(new Order("0001", "This is product 2", (float)12.00, 14));
		orders.add(new Order("0002", "This is product 3", (float)1.30, 12));
		orders.add(new Order("0003", "This is product 4", (float)12.00, 14));
		orders.add(new Order("0004", "This is product 5", (float)141.00, 34));
		orders.add(new Order("0005", "This is product 6", (float)2.23, 23));
		orders.add(new Order("0006", "This is product 7", (float)2.20, 213));
		orders.add(new Order("0007", "This is product 8", (float)1.24, 56));
		orders.add(new Order("0008", "This is product 9", (float)21.02, 4));
		orders.add(new Order("0009", "This is product 10", (float)4.00, 64));
		orders.add(new Order("00010", "This is product 11", (float)5.02, 3));
		orders.add(new Order("00011", "This is product 12", (float)121.00, 16));
		orders.add(new Order("00012", "This is product 13", (float)0.94, 13));
	}

	// Getters and Setters
	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
	
	
}
